# R290 — P10/P14 feedback remediation, November 20, 2026

STATUS: CPU source regression passed, live audio input probes generated,
native acoustic review pending. Not deployed; R285/R286 AUDIO QA HOLD remains.

## What changed

Source: frozen R267 candidate frontend and published R276 pronunciation
dictionary (SHA 455bc74c2e5d4bf8960a10d38c6e2ce258cf07aef87ed3512ea0fc06fe693289).

Only the isolated normalizer.py and segmenter.py differ from frozen R267.

- P14: Thai repetition mark after เป็นช่วง now repeats only ช่วง, not เป็นช่วง.
  Both the spaced and unspaced forms are handled conservatively.
- P14 sentence streaming: never cut between เป็นช่วง and ช่วง.
- P10 sentence streaming: keep the Thai two-word Smart Plug rendering intact
  specifically in the before-device-setup context. Leave standalone Smart
  Plug unchanged: it is a customer PASS control.
- P10 whole-context: baseline model input is unchanged; three semantically
  equivalent input-boundary experiments were synthesized separately using
  the existing live default voice, not an undeployed R290 image.

Minimal transplantable patch, based on R267:
evidence/R290_MINIMAL_FRONTEND_R267_BASE.patch

Never overwrite an actual deployed image with the whole isolated_app tree.
Check the actual serving image digest and frontend source SHA before
transplanting these two small patches.

## CPU and audio verification

- 7/7 R267 original tests pass under R290 isolated frontend.
- 20 archived blind-review prompts: 19 unchanged in whole-context mode.
  P14 changes only its one known repeated predicate.
- 113 customer PASS terms x three source spellings: 339/339 same model input.
- All 113 customer PASS terms have unchanged sentence-mode chunking.
- P10 and P14 HTTP one-shot vs WS character-delta sentence chunk lists match.
- Four new candidate 48k WAVs via user-specified live32611, voice default,
  seed 20261111, speed 1; all matched response input/output SHA and seed.
- Archived P10 and P14 comparison WAVs were reused unchanged.
- Browser review package has 6 cases: four A/B comparisons and two
  P05/P15 unchanged controls; 10 playable lossless audio takes. Chrome
  metadata playback, JSON export and reload persistence all checked.
- 8/8 isolated R290 contract tests pass.

Audio duration is not quality proof:
P14 original 4.48s, candidate 4.48s;
P10 baseline 6.56s, three alternatives 5.28s / 5.92s / 5.12s.

HTML on user's Mac:
~/Downloads/ThaiTTS_R290_P10_P14_ThaiNative_AB_20261120.html

Private answer key is separately held at
evidence/PRIVATE_R290_AB_KEY_DO_NOT_SHARE.json
and must never be sent to a reviewer.

## R286 second review (not training gold)

The source reviewer field is blank, completed=0, but 6/6 transcripts exist.
All six original WAV SHA values match both the prior JJJ source identities
and the actual source WAVs on show_torch.

Keep R282 candidate hold, 1-based rows:
359701, 1563710, 2631346, 3323714.
Prioritize R283-02 and R283-04 for independent human arbitration. R283-17
and ROOT-03 still lack final verdicts; longer text alone does not settle the
audio boundary or label content.

Remote receipt:
evidence/R290_SECOND_REVIEW_REMOTE_VERIFICATION.json

## Mandatory gates before release

1. Native speaker compares the four R290 A/B pairs in full Thai context.
2. Source image digest and approved default ref_continuation cache verified.
3. Candidate image tested on the single authorized RTX 3090 for both HTTP
   and WS PCM/MP3 with seed, instructions and Stop/tail regressions.
4. Keep the 113 PASS terms, plus long-context and varied-seed controls.
5. No training or automatic human/Whisper transcript substitution while
   R285/R286 AUDIO QA HOLD remains.

Repro entrypoints:
audit_frontend.py, import_second_r286_review.py, test_r290_contracts.py,
build_r290_review_html.py and generate_r290_audio.py.

