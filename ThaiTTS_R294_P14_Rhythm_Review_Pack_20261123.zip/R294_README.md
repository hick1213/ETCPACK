# R294 — Thai TTS Jina November 23 native review

State: R293 P10/P15 gain positive native evaluation; P14 rhythmic detail still requires listening. No deployment or training.

The latest exact user-supplied review is source/Thai_TTS_R293_native_Jina_23Nov_01.json, SHA256 c07b5cc2d733edf18ee477c7e89632bd441ce95899c09bfbc159e5f4626d7333.

## Real conclusions

- All 6 responses have verdicts. A/B identities and original WAV SHA values verified against the private R293 mapping.
- P10 canonical Thai setup input, speed 1.00, is preferred over old spaced R290 input, naturalness 5/5. Raw English source and canonical Thai are tied, 5/5 both. Slower 1.00 is preferred over 1.10 for instructional clarity. NO global speed adjustment.
- P15 joined numeral classifier has repeated strong preference, 5/5 naturalness.
- P14 fully joined repetition is preferred 4/5 over periodic-only 3/5, but has lingering slightly unnatural rhythm around ช้า ๆ.
- P05 existing control remains PASS, 5/5.

This feedback appears to be a further round by prior reviewer Jina, not proof of a third independent person.

## New P14-only acoustic experiments

Using user Live32611 existing default voice, no model code change:

1. P14_join_tail_with_due: remove only the pause-inducing space before ด้วยนะคะ. 4.32 seconds.
2. P14_seed_20261110: same model text, alternate seed 20261110. 4.64 seconds.
3. P14_speed_095: same model text and seed 20261111, speed 0.95. 4.547 seconds.

Baseline fully joined candidate remains 4.32 seconds at seed 20261111 and speed 1.
All three new 48k PCM WAVs pass request/response SHA, sample integrity and no-clipping checks. They are research audio, not a claim of improved native pronunciation.

New offline HTML:
~/Downloads/ThaiTTS_R294_P14_Rhythm_Native_AB_20261123.html

It contains three randomized A/B comparisons and a P05 unchanged control; seven losslessly compressed FLAC tracks. Chrome audio metadata, export and refresh persistence passed. The private answer key is separately stored and must never be given to reviewers.

## QA and deployment discipline

- 6/6 native response/identity checks.
- R293 7/7, R291 6/6 and R294 5/5 contracts pass.
- Original 20 prompts and 113 PASS x 3 spellings are unchanged by this round.
- Existing verified R293 normalizer, R291 segmenter, model, voice and seed were not changed in production.
- R294_RELEASE_GATE.json keeps production release and training forbidden.
- R285/R286 AUDIO QA HOLD remains completely separate, unchanged.

Before any production release: native listening of new P14 rhythms, verify the exact production OCI image/voice-cache binding, isolated RTX3090 HTTP/WS PCM/MP3/StopHead tests, and representative audio controls from the 113 PASS words.

Project commands:
python audit_r294_feedback.py
python generate_p14_rhythm_probes.py
python build_p14_rhythm_html.py
python -m unittest -v test_r294_contracts.py
