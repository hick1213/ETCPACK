# R293 Thai native QA — Jina_03 and Thiwan C.

Date: November 20, 2026. Research candidate; nothing deployed or trained.

## Sources and adjudication

Jina_03 source file in source/Thai_TTS_R291_native_Jina_03.json:
SHA256 3231f0d21544f37f47192db7b30f3f62d06e342bc44fc179bc75f3a644a3fe58.
Thiwan C. source in the prior R292 review project. Both reviews are independently
completed for the same nine exact R291 audio sets. All nine WAV assignments
were checked against the separate private key. Seven of nine choices match.
The only differences are on P10 tempo comparisons.

P14 exact joined repetition and periodic-only joined repetition were both
preferred by each reviewer. The full phrase is native requested and rated
naturalness 4/5 to 5/5 by Jina; no direct head-to-head exact-vs-periodic
result existed before this revision.

P15 joined numeral/classifier was preferred by both listeners; Jina marked
it excellent and 5/5. P05 unchanged control passed with both (5/5).

P10: the old 1.00x speed is preferred/tied against 1.05x, and 1.10x has
only low-confidence preference from Jina and a tie from Thiwan. KEEP 1.00x
as the candidate default; no global speed adjustment.

## Actual newly found source bug

Jina proposed this source phrase:
กรุณาเชื่อมต่อWi-Fi และเปิดBluetooth ก่อนตั้งค่าSmart Plug นะคะ

Under frozen R291, the resulting normalized phrase still has an internal
space before ปลั๊ก. The original precision rule recognized only a space
after ก่อนตั้งค่า.

The R293 isolated candidate changes one tightly scoped regex in
normalizer.py to accept zero or more spaces, producing:
กรุณาเชื่อมต่อไวไฟ และเปิดบลูทูธ ก่อนตั้งค่าสมาร์ตปลั๊ก นะคะ

Only normalizer.py differs from the frozen R291 source. The minimal patch
R293_MINIMAL_NORMALIZER_FROM_R291.patch has been independently replayed
against R291 with identical output file SHA.

## Programmatic gates

Original 20 sentences unchanged in none/sentence one-shot/WS modes.
All 113 previously passing customer terms x three source spellings: 339/339
unchanged. Jina exact raw sentence produces identical model text in
one-shot and character-by-character WS. Original R267 regression: 7/7 pass.
R293 safety contracts: 7/7 pass.

## Real audio and mini blind review

Existing user endpoint: http://ai.wgine-dev.com:32611/v1/audio/speech
Voice default, model voxcpm2, seed 20261111, 48kHz PCM WAV.

New audio requests on the EXISTING live service, not a deployed R293 image:
Jina original English wording 1.00x: 4.64 seconds.
Jina canonical Thai wording 1.00x: 4.64 seconds.
Jina canonical Thai wording 1.10x: 4.218 seconds.
Prior selected R290 model input 1.00x: 5.92 seconds.

All waveform SHA, response input SHA, seed and clipping checks passed.
These mechanical tests do NOT establish audio content completeness or
naturalness. Thai native listening is required.

New six-case offline review HTML on the user's Mac Downloads folder:
ThaiTTS_R293_Jina_03_P10_P14_P15_Blind_20261120.html

It contains 5 A/B comparisons plus an unmodified P05 positive control,
11 FLAC audio players. Private A/B key is never embedded or distributed.
Chrome playback, JSON export and state reload were tested.

## Remaining release gates

First, Thai native review of the new P10 short clips for swallowing,
mispronunciation, timing and end tails. The shorter 4.64s duration must
NOT be assumed to be better.

Then confirm actual source image digest and default reference voice
configuration and run isolated-image HTTP/WS PCM/MP3 on authorized RTX3090.
Maintain lexical PASS controls and R285/R286 training AUDIO QA HOLD.

No images have been built/pushed/deployed. No model weights, production
services or R281/R282 training labels were changed.
